; GWBASIC
;
; Demonstrates MS-DOS memory allocation and deallocation functions.
;
; Works with GWBASIC.EXE because the .EXE loader only allocates the memory
; required by the .EXE file and leaves free RAM for MS-DOS memory management.
; Will NOT work with MBASIC.COM because .COM files always allocate all memory.
; In this case the COM file would have to shrink the allocated excess RAM size.
;
;
; Building:
; ---------
; MASM DOSMEM,DOSMEM;
; LINK DOSMEM;                 Neglect "no stack segment" warning
; EXE2BIN DOSMEM.EXE DOSMEM.BIN
; DEL DOSMEM.EXE
;
; or:
;
; TASM /L DOSMEM
; TLINK DOSMEM
; EXE2BIN DOSMEM.EXE DOSMEM.BIN
; DEL DOSMEM.EXE
;
; Martin Hepperle, 2025
;
; ------------------------------------------------------
; Macro only for output of dimensioning of BASIC array
INTSIZE MACRO X
 %OUT REM required array size:  DIM CODE%(X)
ENDM
IF2
 ; round up to size array of 16-bit integers, BASIC arrays are 0-based
 INTSIZE %(END_OF_CODE-START_OF_CODE+1)/2-1
ENDIF
; ------------------------------------------------------
CODE SEGMENT

     ASSUME CS:CODE

     ; Usage:
     ; CALL ALLOCSEG ( BYTES%, SEG% )
     ; CALL FREESEG  ( SEG% )
     ;
     ; Example:
     ; Allocate some space using MS-DOS to find a free segment above BASIC.
     ; Write some data to this allocated block.
     ; Dellocate that space.
     ; 10 DIM CODE%(32)
     ; 20 BLOAD "DOSMEM.BIN",VARPTR(CODE%(0))
     ; 30 IF CODE%(0)=0 THEN STOP
     ; 40 BYTES%=32767 : SEG%=0 : REM allocate 512 bytes
     ; 50 ALLOCSEG%=VARPTR(CODE%(0))
     ; 60 CALL ALLOCSEG%(BYTES%,SEG%)
     ; 70 IF SEG%=0 THEN PRINT "Could not allocate." : GOTO 170
     ; 80 PRINT "Allocated";BYTES%;"bytes in segment &H";HEX$(SEG%)
     ; 90 DEF SEG=SEG%
     ; 100 FOR I%=0 TO BYTES%-32 STEP 32 : POKE I%,255 : NEXT I%
     ; 110 FOR I%=0 TO BYTES%-32 STEP 32 : B%=PEEK(I%) : NEXT I%
     ; 120 PRINT "Used";BYTES%\32;"bytes in segment &H";HEX$(SEG%)
     ; 130 DEF SEG
     ; 140 FREESEG%=VARPTR(CODE%(0))+3
     ; 150 CALL FREESEG%(SEG%)
     ; 160 PRINT "Freed";BYTES%;"bytes in segment &H";HEX$(SEG%)
     ; 170 END
     ;
     ; All parameters are passed from BASIC by reference.
     ;
     ; Allocate a segment SEG% for BYTES% bytes.
     ; CALL ALLOCSEG ( BYTES%, SEG% )
     ;       +8  BYTES%  offset 1. parameter
     ;       +6  SEG%    offset 2. parameter
     ;       +4  return  address segment CS, pushed by far call
     ;       +2  return  address offset  IP, pushed by far call
     ; SP->  +0  BP saved (after PUSH BP)
     ;
     ; Deallocate the segment SEG% , which msut have been allocated by ALLOCSEG before.
     ; CALL DOSMEM ( SEG% )
     ;       +6  SEG%    offset 1. parameter
     ;       +4  return  address segment CS, pushed by far call
     ;       +2  return  address offset  IP, pushed by far call
     ; SP->  +0  BP saved (after PUSH BP)

; for addressing stack frame with parameter(s)
ALLOC_FRAME STRUC          ; offset
               DW ?        ;   0    saved BP
               DW 2 DUP(?) ;   2    RETURN far address
       SEG%    DW ?        ;   6    second parameter offset
       BYTES%  DW ?        ;   8    first parameter offset
ALLOC_FRAME ENDS

     ; BLOAD header, must appear first in CODE segment
     _MAGIC  DB 0FDh
     _SEG    DW ?                ; not used
     _OFF    DW ?                ; not used
     _LEN    DW END_OF_CODE-$    ; number of bytes

START_OF_CODE   LABEL   NEAR

      JMP  ALLOCSEG        ; START_OF_CODE + 0
      JMP  FREESEG         ; START_OF_CODE + 3

; ------------------------------------------------------

ALLOCSEG   PROC FAR         ; must be FAR

      PUSH BP
      MOV  BP,SP           ; hold on to stack

      PUSH ES              ; save

      MOV  BX,[BP].BYTES%  ; offset of BYTES% count
      MOV  BX,[BX]         ; get BYTES%
      SHR  BX,1            ; / 2   convert
      SHR  BX,1            ; / 4   .
      SHR  BX,1            ; / 8   .
      SHR  BX,1            ; / 16  to paragraphs

      MOV  AH,48h          ; MS-DOS: allocate
      INT  21h             ; returns segment in AX
      JC   OOPS            ; jif failure
      JMP  DONE            ; 

OOPS:                      ; could not allocate
      XOR AX,AX            ; return NULL

DONE:
      MOV  BX,[BP].SEG%    ; offset of SEG%
      MOV  [BX],AX         ; 

      POP ES               ; restore

      POP  BP
      RET  2*2             ; drop addresses of 2 parameters
   
ALLOCSEG   ENDP

; ------------------------------------------------------

FREESEG   PROC FAR         ; must be FAR

      PUSH BP
      MOV  BP,SP           ; hold on to stack

      PUSH ES              ; save

      MOV  BX,[BP].SEG%    ; offset of SEG%
      MOV  AX,[BX]         ; get SEG%
      
      MOV  ES,AX           ; free allocated segment
      MOV  AH,49h          ; MS-DOS: deallocate
      INT  21h

      POP ES               ; restore

      POP  BP
      RET  1*2             ; drop addresses of 1 parameter
   
FREESEG   ENDP

; ------------------------------------------------------

END_OF_CODE   LABEL   NEAR

CODE ENDS
     
     END

