; MS-BASIC, GWBASIC
;
; Building:
; ---------
; MASM OCC$,OCC$;
; LINK OCC$;                 Neglect "no stack segment" warning
; EXE2BIN OCC$.EXE OCC$.BIN
; DEL OCC$.EXE
;
; or:
;
; TASM /L OCC$
; TLINK OCC$
; EXE2BIN OCC$.EXE OCC$.BIN
; DEL OCC$.EXE
;
; Martin Hepperle, 2025
;
; ------------------------------------------------------
; Macro only for output of dimensioning of BASIC array
INTSIZE MACRO X
 %OUT REM required size:  DIM CODE%(X)
ENDM
IF2
 ; round up to size array of 16-bit integers
 INTSIZE %(END_OF_CODE-START_OF_CODE+1)/2-1
ENDIF
; ------------------------------------------------------
CODE SEGMENT

     ASSUME CS:CODE

     ; Usage:
     ; CALL OCC ( INS$, C%, N% )
     ;
     ; Count occurances of the character C% in the string INS$ and return it in N%.
     ;
     ; Example:
     ; 10 DIM ADR%(21)
     ; 20 BLOAD "OCC$.BIN",VARPTR(ADR%(0))
     ; 30 IF ADR%(0)=0 THEN STOP
     ; 40 A$="SMALL WORLD"
     ; 50 I%=ASC("L") : N%=0 : REM   allocate all simple vars
     ; 60 OCC%=VARPTR(ADR%(0)) : REM before getting address
     ; 70 CALL OCC%(A$,I%,N%) : REM  of OCC$
     ; 80 PRINT "'";A$;"' contains ";N%;" occurances of '";CHR$(I%);"'"
     ; 90 END
     ;
     ; All parameters are passed from BASIC by reference,
     ; i.e. offsets to the string descriptor in string space.
     ; BASICs string space lives in the data segment.
     ;
     ; The string descriptor contains:
     ; 1 byte: string length
     ; 1 word: offset into DS (inside string pool)
     ;
     ; CALL OCC ( INS$, C%, N% )
     ;      +10  INS$  offset 1. parameter
     ;       +8  C%    offset 2. parameter
     ;       +6  N%    offset 3. parameter
     ;       +4  return address segment CS, pushed by far call
     ;       +2  return address offset  IP, pushed by far call
     ; SP->  +0  BP saved (after PUSH BP)

     ; BLOAD header, must appear first in CODE segment
     _MAGIC  DB 0FDh
     _SEG    DW ?                ; not used
     _OFF    DW ?                ; not used
     _LEN    DW END_OF_CODE-$    ; number of bytes

START_OF_CODE   LABEL   NEAR

OCC   PROC FAR   ; must be FAR
   
      PUSH BP
      MOV  BP,SP         ; hold on to stack

      MOV  SI,[BP+10]    ; offset of the INS$ descriptor
      MOV  CL,[SI]       ; string length

      OR   CL,CL         ; length of input?
      JZ   NOLEN         ; zero length string: do nothing

      XOR  CH,CH         ; zero upper byte of length word

      MOV  SI,[SI+1]     ; source string offset

      MOV  DI,[BP+8]     ; offset of C% character code
      MOV  BX,[DI]       ; search character code in BL

      XOR AX,AX          ; zero character count

NEXT:
      MOV BH,[SI]
      INC SI             ; to next string char
      CMP BH,BL
      JNZ NOPE
      INC AL             ; count this occurance (max. 255)
NOPE:
      LOOP NEXT          ; another character

      MOV  DI,[BP+6]     ; offset of the N%
      MOV  [DI],AX       ; count

NOLEN:
      POP  BP
      RET  3*2           ; drop addresses of 3 parameters
   
OCC   ENDP

END_OF_CODE   LABEL   NEAR

CODE ENDS
     
     END

