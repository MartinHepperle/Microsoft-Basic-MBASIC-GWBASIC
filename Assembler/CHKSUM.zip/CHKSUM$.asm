; MS-BASIC, GWBASIC
;
; Building:
; ---------
; MASM CHKSUM$,CHKSUM$;
; LINK CHKSUM$;                 Neglect "no stack segment" warning
; EXE2BIN CHKSUM$.EXE CHKSUM$.BIN
; DEL CHKSUM$.EXE
;
; or:
;
; TASM /L CHKSUM$
; TLINK CHKSUM$
; EXE2BIN CHKSUM$.EXE CHKSUM$.BIN
; DEL CHKSUM$.EXE
;
; Martin Hepperle, 2025
;

; ---------------------------------------------------
; Macro only for output of dimensioning of BASIC array
INTSIZE MACRO X
 %OUT REM required size:  DIM CODE%(X)
ENDM
IF2
 ; round up to size array of 16-bit integers
 INTSIZE %(END_OF_CODE-START_OF_CODE+1)/2-1
ENDIF
; ---------------------------------------------------

CODE SEGMENT

     ASSUME CS:CODE

     ; Usage:
     ; CALL CHKSUM ( S$, C% )
     ; Sum the bytes of all characters in the string S$
     ; and return the 16-bit sum in N%.
     ; Note: if an 8-bit sum is desired, AND the result with 255.
     ;
     ; CALL CRC16  ( S$, C% )
     ; Calculate the CRC-16 over the bytes of all characters in 
     ; the string S$ and return the 16-bit CRC in N%.
     ;
     ;
     ; Example:
     ; 10 DIM ADR%(18)
     ; 20 BLOAD "CHKSUM$.BIN",VARPTR(ADR%(0))
     ; 30 IF ADR%(0)=0 THEN STOP
     ; 40 A$="SMALL WORLD"
     ; 50 C%=0 : REM   allocate all simple vars
     ; 60 CHKSUM%=VARPTR(ADR%(0))
     ; 70 CALL CHKSUM%(A$,C%) : REM     of CHKSUM$
     ; 80 PRINT "SUM-16 of  '";A$;"' is &H";HEX$(C%)
     ; 90 CRC16%=VARPTR(ADR%(0))+3
     ; 100 CALL CRC16%(A$,C%) : REM     of CHKSUM$
     ; 110 PRINT "CRC-16 of '";A$;"' is &H";HEX$(C%)
     ; 120 END
     ;
     ; All parameters are passed from BASIC by reference,
     ; i.e. offsets to the string descriptor in string space.
     ; BASICs string space lives in the data segment.
     ;
     ; The string descriptor contains:
     ; 1 byte: string length
     ; 1 word: offset into DS (inside string pool)
     ;
     ; CALL CHKSUM ( INS$, C% )
     ;       +8  S$    offset 1. parameter
     ;       +6  N%    offset 2. parameter
     ;       +4  return address segment CS, pushed by far call
     ;       +2  return address offset  IP, pushed by far call
     ; SP->  +0  BP saved (after PUSH BP)

     ; BLOAD header, must appear first in CODE segment
     _MAGIC  DB 0FDh
     _SEG    DW ?                ; not used
     _OFF    DW ?                ; not used
     _LEN    DW END_OF_CODE-$    ; number of bytes

START_OF_CODE LABEL NEAR
     JMP CHKSUM  ; ADR%(0)
     JMP CRC16   ; ADR%(0)+3

; for addressing stack frame with parameters
STACK_FRAME STRUC           ; offset
               DW ?         ;   0    saved BP
               DW 2 DUP(?)  ;   2    FAR return address, offset, segment
       N%      DW ?         ;   6    second parameter
       S$      DW ?         ;   8    first parameter
STACK_FRAME ENDS
; -------------------------------------------------------------
CHKSUM   PROC FAR   ; must be FAR

      PUSH BP
      MOV  BP,SP         ; hold on to stack

      CALL SETUP
      JZ   DONE          ; zero length string: do nothing

      XOR BH,BH          ; zero upper byte for 16-bit addition

NEXT_1:
      MOV BL,[SI]
      ADD AX,BX
      INC SI             ; to next string char
      LOOP NEXT_1        ; another character

DONE:
      MOV  DI,[BP].N%    ; DI = offset of N%
      MOV  [DI],AX       ; return sum

      POP  BP
      RET  2*2           ; drop addresses of 3 parameters
   
CHKSUM   ENDP
; -------------------------------------------------------------
CRC16 PROC   NEAR
; uses AX,BX,CL 

      PUSH BP
      MOV  BP,SP         ; hold on to stack

      CALL SETUP
      JZ   DONE          ; zero length string: do nothing

NEXT_2:
      MOV BL,[SI]        ; get byte
      INC SI             ; to next string char

      PUSH CX         ; save
      XOR BX,AX       ; AL contains (X7-0 XOR Y7-0)
      XOR BH,BH       ; clear AH
      MOV CL,8
      SHR AX,CL       ; BL contains (X15-8), clear BH
      OR  BX,BX       ; set parity flag
      JPE CRC16X      ; if (X7-0 XOR Y7-0) has odd parity 
      XOR AX,0C001h   ; then adjust CRC bits 15, 14, and 0
CRC16X: MOV CL,6
      ROL BX,CL
      XOR AX,BX
      ROL BX,1
      XOR AX,BX       ; BX has new CRC-16 accumulation
      POP CX          ; restore

      LOOP NEXT_2     ; handle next byte

      JMP DONE

CRC16 ENDP
; -------------------------------------------------------------

; -------------------------------------------------------------
; Set registers from first BASIC parameter (S$)
; AX = zero return value
; CX = length of string S$
; SI = offset of string S$
; set ZERO flag if string has zero length
;
SETUP PROC   NEAR
      XOR  AX,AX         ; zero return value
      MOV  SI,[BP].S$    ; offset of the S$ descriptor
      MOV  CL,[SI]       ; string length
      XOR  CH,CH         ; zero upper byte of length word
      MOV  SI,[SI+1]     ; source string offset 
      OR   CL,CL         ; length of input?
      RET
SETUP ENDP
; -------------------------------------------------------------

END_OF_CODE   LABEL   NEAR

CODE ENDS
     
     END

