10 DIM ADR%(50)
20 BLOAD "CHKSUM$.BIN",VARPTR(ADR%(0))
30 IF ADR%(0)=0 THEN STOP
40 A$="Hello Checksum, how are you?"
50 A$="ABC"
60 C%=0 : REM allocate all simple vars
70 CHKSUM%=VARPTR(ADR%(0))
80 CALL CHKSUM%(A$,C%)
90 PRINT "'";A$;"' sums to";C%;"=";C% AND 255;"= &H";HEX$(C%)
100 CRC16%=VARPTR(ADR%(0))+3
110 CALL CRC16%(A$,C%)
120 PRINT "'";A$;"' CRC-16s to &H";HEX$(C%)
130 END
